package com.ust.dsms.billing.arithmetic.operator;

public class OperatorAdd implements ArithmeticOperator {

  @Override
  public boolean apply(Object leftValue, Object rightValue) {
    // TODO Auto-generated method stub
    return false;
  }

}
