package com.ust.dsms.billing.function;

public abstract class BaseFunction implements Comparable<BaseFunction>{
  
  private int index;
  
  public abstract void execute();
  
  public BaseFunction() {
    super();
    // TODO Auto-generated constructor stub
  }

  public BaseFunction(int index) {
    super();
    this.index = index;
  }

  public int getIndex() {
    return index;
  }
  public void setIndex(int index) {
    this.index = index;
  }

  @Override
  public int compareTo(BaseFunction o) {
    // TODO Auto-generated method stub
    return 0;
  }
}
