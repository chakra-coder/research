package com.ust.dsms.billing.relational.operator;


public class OperatorGreaterThan implements RelationalOperator {
  @Override
  public boolean apply(Object leftValue,Object rightValue) {
    return false;
  }
}
