package com.ust.dsms.billing.relational.operator;

public interface RelationalOperator {
  boolean apply(Object leftValue,Object rightValue);
}
