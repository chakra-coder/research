package com.ust.dsms.billing.arithmetic.operator;

public interface ArithmeticOperator {
  boolean apply(Object leftValue,Object rightValue);
}
