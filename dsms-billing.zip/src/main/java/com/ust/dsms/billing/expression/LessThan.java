package com.ust.dsms.billing.expression;

import com.ust.dsms.billing.relational.operator.OperatorLessThan;
import com.ust.dsms.billing.relational.operator.RelationalOperator;

public class LessThan extends BaseExpression {

  public LessThan() {
    super();
  }

  public LessThan(String leftOpernad, String rightOpernad) {
    super(leftOpernad, rightOpernad);
  }

  @Override
  public RelationalOperator getOperator(Object leftOpernadValue, Object rightOpernadValue) {
    return new OperatorLessThan();
  }

  @Override
  public String toString() {
    return "LessThan [leftOpernad=" + leftOpernad + ", rightOpernad=" + rightOpernad + "]";
  }
  
}
