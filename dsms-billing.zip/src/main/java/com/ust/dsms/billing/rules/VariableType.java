package com.ust.dsms.billing.rules;

public enum VariableType {
    STRING,LONG,DOUBLE,DATE
}
