package com.ust.dsms.billing.research;

import java.util.Set;
import java.util.TreeSet;

import com.ust.dsms.billing.expression.AndExpression;
import com.ust.dsms.billing.expression.BaseExpression;
import com.ust.dsms.billing.expression.GreaterThan;
import com.ust.dsms.billing.expression.LessThan;
import com.ust.dsms.billing.expression.Rule;
import com.ust.dsms.billing.function.FunctionAdd;
import com.ust.dsms.billing.rules.utils.XStreamHelper;


public class TestXstream {
    public static void main(String[] args) {
        
        AndExpression and = new AndExpression();
        BaseExpression expression1 = new  GreaterThan("amount", "100");
        BaseExpression expression2 = new LessThan("amount", "1000");
        
        Rule rule = new Rule("Rule 1",1,and);
        rule.getTrueFunctions().add(new FunctionAdd("a","b",1));
        
        
        and.getExpressions().add(expression1);
        and.getExpressions().add(expression2);
        Set<Rule> rules = new TreeSet<>();
        rules.add(rule);
        
        XStreamHelper helper=new XStreamHelper();
        
        System.out.println(helper.toXml(rules));
        
        Set<Rule> rule2=(Set<Rule>) helper.fromXml("/home/sajith/workspace/OnTime/dsms-billing/src/main/resources/rules.xml");
        System.out.println(rule2);
    }    

        
  

}
