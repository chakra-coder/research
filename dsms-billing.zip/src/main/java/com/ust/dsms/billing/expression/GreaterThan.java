package com.ust.dsms.billing.expression;


import com.ust.dsms.billing.relational.operator.OperatorGreaterThan;
import com.ust.dsms.billing.relational.operator.RelationalOperator;

public class GreaterThan extends BaseExpression {
  
  public GreaterThan() {
    super();
  }

  public GreaterThan(String leftOpernad, String rightOpernad) {
    super(leftOpernad, rightOpernad);
  }

  @Override
  public RelationalOperator getOperator(Object leftOpernadValue, Object rightOpernadValue) {
    return new OperatorGreaterThan();
  }

  @Override
  public String toString() {
    return "GreaterThan [leftOpernad=" + leftOpernad + ", rightOpernad=" + rightOpernad + "]";
  }
  
  
}
