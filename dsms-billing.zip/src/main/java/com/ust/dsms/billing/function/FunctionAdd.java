package com.ust.dsms.billing.function;

public class FunctionAdd extends BaseFunction {

  private String leftOpernad;
  private String rightOpernad;
  
  @Override
  public void execute() {
    // TODO Auto-generated method stub
    
  }
  
  public FunctionAdd(String leftOpernad, String rightOpernad,int index) {
    super(index);
    this.leftOpernad = leftOpernad;
    this.rightOpernad = rightOpernad;
  }

  public String getLeftOpernad() {
    return leftOpernad;
  }

  public void setLeftOpernad(String leftOpernad) {
    this.leftOpernad = leftOpernad;
  }

  public String getRightOpernad() {
    return rightOpernad;
  }

  public void setRightOpernad(String rightOpernad) {
    this.rightOpernad = rightOpernad;
  }

  @Override
  public String toString() {
    return "FunctionAdd [leftOpernad=" + leftOpernad + ", rightOpernad=" + rightOpernad + "]";
  }
  
}
