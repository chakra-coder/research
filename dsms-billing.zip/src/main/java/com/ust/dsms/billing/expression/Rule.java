package com.ust.dsms.billing.expression;

import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.ust.dsms.billing.function.BaseFunction;
import com.ust.dsms.billing.rules.service.RuleService;

public class Rule implements Comparable<Rule> {

    private String description;
    private int index;
    private Expression expression;
    private Set<BaseFunction> trueFunctions = new TreeSet<>();
    private Set<BaseFunction> falseFunctions = new TreeSet<>();

    public void execute(RuleService ruleService,Map<String, Object> data) {
        if (expression.isTrue(ruleService,data)) {
            for (BaseFunction function : trueFunctions) {
                function.execute();
            }
        } else {
            for (BaseFunction function : falseFunctions) {
                function.execute();
            }
        }
    }

    public Rule(String description, int index, Expression expression) {
      super();
      this.description = description;
      this.index = index;
      this.expression = expression;
    }

    public Set<BaseFunction> getTrueFunctions() {
      return trueFunctions;
    }

    public void setTrueFunctions(Set<BaseFunction> trueFunctions) {
      this.trueFunctions = trueFunctions;
    }

    public Set<BaseFunction> getFalseFunctions() {
      return falseFunctions;
    }

    public void setFalseFunctions(Set<BaseFunction> falseFunctions) {
      this.falseFunctions = falseFunctions;
    }

    @Override
    public int compareTo(Rule o) {
      // TODO Auto-generated method stub
      return 0;
    }

    public String getDescription() {
      return description;
    }

    public void setDescription(String description) {
      this.description = description;
    }

    public int getIndex() {
      return index;
    }

    public void setIndex(int index) {
      this.index = index;
    }

    public Expression getExpression() {
      return expression;
    }

    public void setExpression(Expression expression) {
      this.expression = expression;
    }

    public Rule() {
      super();
      // TODO Auto-generated constructor stub
    }

    @Override
    public String toString() {
      return "Rule [description=" + description + ", index=" + index + ", expression=" + expression + ", trueFunctions=" + trueFunctions + ", falseFunctions=" + falseFunctions
        + "]";
    }
    
    
}
