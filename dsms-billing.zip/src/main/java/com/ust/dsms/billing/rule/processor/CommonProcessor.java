package com.ust.dsms.billing.rule.processor;

import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;

import com.ust.dsms.billing.expression.Rule;
import com.ust.dsms.billing.rules.service.RuleService;

public class CommonProcessor implements ItemProcessor<Map<String, Object>, Map<String, Object>> {

    private static final Logger log = LoggerFactory.getLogger(CommonProcessor.class);

    @Autowired
    private RuleService ruleService;

    @Override
    public Map<String, Object> process(final Map<String, Object> data) throws Exception {
        
        Set<Rule> rules = ruleService.getRules();
        for (Rule rule : rules) {
            rule.execute(ruleService,data);
        }

        return data;

    }
}
