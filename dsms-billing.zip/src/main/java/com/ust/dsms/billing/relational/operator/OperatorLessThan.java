package com.ust.dsms.billing.relational.operator;

public class OperatorLessThan implements RelationalOperator {
  @Override
  public boolean apply(Object leftValue,Object rightValue) {
    return false;
  }
}
