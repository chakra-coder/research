package com.ust.dsms.billing.rules.service;

import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ust.dsms.billing.expression.Rule;
import com.ust.dsms.billing.rules.utils.XStreamHelper;

@Component
public class RuleService {

  private static final Logger log = LoggerFactory.getLogger(RuleService.class);

  private static final String FORMAT_DOUBLE = "[+-]*([0-9]*[.])?[0-9]+";
  private static final String FORMAT_LONG = "[+-]*([0-9]*)+";

  private Set<Rule> rules;

  @Autowired
  private XStreamHelper xStreamHelper ;
  
  @Autowired
  private VariableService variableService;

  public Set<Rule> getRules() {

    return this.rules;
  }

  @PostConstruct
  public void initialize() {

  

    this.rules = (Set<Rule>) xStreamHelper.fromXml("/home/sajith/workspace/OnTime/dsms-billing/src/main/resources/rules.xml");

    log.info("Rules loaded");

  }

  public Object get(String variableName, Map<String, Object> data) {

    if (isDouble(variableName)) {
      return Double.valueOf(variableName);
    }

    if (isLong(variableName)) {
      return Long.valueOf(variableName);
    }

    if (data.containsKey(variableName)) {
      return data.get(variableName);
    }

    Object value = variableService.get(variableName, data);
    return value == null ? variableName : value;

  }

  private boolean isDouble(String value) {
    return value.matches(FORMAT_DOUBLE);
  }

  private boolean isLong(String value) {
    return value.matches(FORMAT_LONG);
  }

}
